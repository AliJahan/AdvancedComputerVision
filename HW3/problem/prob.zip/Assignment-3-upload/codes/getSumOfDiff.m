function sod = getSumOfDiff(I)

% I is a 3D tensor of image sequence where the 3rd dimention represents the time axis

% YOUR CODE HERE. DO NOT CHANGE ANYTHING ABOVE THIS.
        