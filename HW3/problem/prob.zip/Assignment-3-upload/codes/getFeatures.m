function feat = getFeatures(I, bbox)

% I is an image
% bbox is a N x 4 matrix, containing the x,y,w,h of each bbox and N is the number of bbox
% feat is a N x n_feat dimensional matrix where n_feat is the feature length

% YOUR CODE HERE. DO NOT CHANGE ANYTHING ABOVE THIS.